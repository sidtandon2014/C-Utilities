﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    public static class StringExtensions
    {
        public static string Repeat(this string input, int count)
        {
            if (!string.IsNullOrEmpty(input))
            {
                StringBuilder builder = new StringBuilder(input.Length * count);

                for (int i = 0; i < count; i++) builder.Append(input);

                return builder.ToString();
            }

            return string.Empty;
        }

        public static void BuildPropertiesList(this PythonObject pythonObject, string prefix, List<string> columnsDeclaration, List<string> call)
        {
            foreach (PythonObjectProperty pythonObjectProperty in pythonObject.ObjectPropertyCollection.Where(item => item.Generate))
            {
                if (pythonObjectProperty.IsCollection && !pythonObjectProperty.IsCollectionOfPrimitiveType)
                {
                    columnsDeclaration.Add($"'{prefix}{pythonObjectProperty.PythonName}'");
                    call.Add($"o.{prefix}{pythonObjectProperty.PythonName}.generateDataFrame()");
                }
                else if (pythonObjectProperty.IsEnumeration)
                {
                    columnsDeclaration.Add($"'{prefix}{pythonObjectProperty.PythonName}'");
                    call.Add($"o.{prefix}{pythonObjectProperty.PythonName}.name");
                }
                else if (!pythonObjectProperty.IsPythonPrimitiveType)
                {
                    PythonObject relatedPythonObject = pythonObject.PythonAssembly.Objects.Where(item => item.PythonName == pythonObjectProperty.PythonTypeName).FirstOrDefault();
                    if (relatedPythonObject != null) relatedPythonObject.BuildPropertiesList($"{prefix}{pythonObjectProperty.PythonName}.", columnsDeclaration, call);
                }
                else
                {
                    columnsDeclaration.Add($"'{prefix}{pythonObjectProperty.PythonName}'");
                    call.Add($"o.{prefix}{pythonObjectProperty.PythonName}");
                }
            }
        }
    }
}
