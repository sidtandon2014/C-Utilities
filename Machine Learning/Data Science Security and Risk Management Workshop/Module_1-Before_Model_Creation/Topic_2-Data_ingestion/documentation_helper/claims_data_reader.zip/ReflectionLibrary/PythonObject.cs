﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

namespace ReflectionLibrary
{
    public class PythonObject
    {
        public PythonObject(PythonAssembly pythonAssembly)
        {
            this.PythonAssembly = pythonAssembly;
        }

        [JsonIgnore]
        public PythonAssembly PythonAssembly { get; set; }
        public string Name { get; set; }
        public string PythonName { get; set; }
        public string BaseClassName { get; set; }
        public string BaseClassPythonName { get; set; }
        public IEnumerable<PythonObjectProperty> ObjectPropertyCollection { get; set; }
        public bool Generate { get; set; }
        public int Order { get; set; }
        public bool NeedsPythonCollectionClass { get; set; }
        public bool GenerateCreateMethod { get; set; }
        public string CreateMethodName { get; set; }
        public string CodeForClass { get; set; }
        public string AdditionalCode { get; set; }
        public string CodeForCollectionClass { get; set; }
    }
}
