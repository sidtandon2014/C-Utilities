﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace ReflectionLibrary
{
    public class PythonEnum
    {
        public PythonEnum(PythonAssembly pythonAssembly)
        {
            this.PythonAssembly = pythonAssembly;
        }

        [JsonIgnore]
        public PythonAssembly PythonAssembly { get; set; }
        public string Name { get; set; }
        public string PythonName { get; set; }
        public IEnumerable<PythonEnumValue> EnumValueCollection { get; set; }
        public bool Generate { get; set; }
    }
}
