﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web.Script.Serialization;

namespace ReflectionLibrary
{
    public class PythonAssembly
    {
        public string AdditionalImportStatements { get; set; }
        public string AdditionalCodeAtStart { get; set; }
        public string AdditionalCodeAtEnd { get; set; }

        public IEnumerable<PythonObject> Objects { get; set; }
        public IEnumerable<PythonEnum> Enums { get; set; }

        private static IEnumerable<AssemblyLocation> AssemblyLocations { get; set; }

        public static PythonAssembly Create(string objectModelAssemblyFile, string originalObjectModelFile, string newObjectModelFile, IEnumerable<AssemblyLocation> assemblyLocations)
        {
            AssemblyLocations = assemblyLocations;

            return (LoadAssemblyMetaData(objectModelAssemblyFile, originalObjectModelFile, newObjectModelFile));
        }

        private static Assembly CurrentDomain_ReflectionOnlyAssemblyResolve(object sender, ResolveEventArgs args)
        {
            string assembly = args.Name.Split(',')[0];

            if (AssemblyLocations == null) return null;

            AssemblyLocation assemblyLocation = AssemblyLocations.Where(item => item.Name == assembly).FirstOrDefault();
            if (assemblyLocation != null) return Assembly.ReflectionOnlyLoadFrom(assemblyLocation.Location);

            return null;
        }

        private static void MoveObjectBefore(PythonAssembly pythonAssembly, PythonObject pythonObject, int order)
        {
            int counter = order + 1;
            pythonObject.Order = -1;

            foreach (PythonObject currentPythonObject in pythonAssembly.Objects.Where(item => item.Order >= order && item.Name != pythonObject.Name))
            {
                currentPythonObject.Order = counter;
                counter++;
            }

            pythonObject.Order = order;
        }

        private static PythonAssembly LoadAssemblyMetaData(string objectModelAssemblyFile, string originalObjectModelFile, string newObjectModelFile)
        {
            string configurationJson = System.IO.File.ReadAllText(Path.Combine(Environment.CurrentDirectory, "configuration.json"));
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            Dictionary<string, object> configurationEntries = serializer.Deserialize<Dictionary<string, object>>(configurationJson);

            AppDomain.CurrentDomain.ReflectionOnlyAssemblyResolve += CurrentDomain_ReflectionOnlyAssemblyResolve;

            System.Reflection.Assembly myAssembly;

            myAssembly = System.Reflection.Assembly.ReflectionOnlyLoadFrom(objectModelAssemblyFile);

            PythonAssembly pythonAssembly = new PythonAssembly();
            pythonAssembly.AdditionalImportStatements = string.Empty;
            pythonAssembly.AdditionalCodeAtStart = string.Empty;
            pythonAssembly.AdditionalCodeAtEnd = string.Empty;

            pythonAssembly.Objects = new List<PythonObject>();
            pythonAssembly.Enums = new List<PythonEnum>();
            int pythonObjectCounter = 0;

            foreach (Type type in myAssembly.GetExportedTypes())
            {
                if (type.IsEnum)
                {
                    PythonEnum pythonEnum = new PythonEnum(pythonAssembly);
                    pythonEnum.Generate = true;
                    pythonEnum.Name = type.Name;
                    pythonEnum.PythonName = type.Name == "Object" ? "object" : type.Name;
                    pythonEnum.EnumValueCollection = new List<PythonEnumValue>();

                    foreach (FieldInfo fieldInfo in type.GetFields())
                    {
                        if (fieldInfo.Name != "value__")
                        {
                            ((List<PythonEnumValue>)pythonEnum.EnumValueCollection).Add(new PythonEnumValue(pythonEnum)
                            {
                                Generate = true,
                                Name = fieldInfo.Name,
                                FullName = string.Format("{0}.{1}", pythonEnum.Name, fieldInfo.Name),
                                PythonName = fieldInfo.Name,
                                Value = fieldInfo.GetRawConstantValue().ToString(),
                                PythonValue = fieldInfo.GetRawConstantValue().ToString(),
                            }); ;
                        }
                    }

                    ((List<PythonEnum>)pythonAssembly.Enums).Add(pythonEnum);


                }
                else if (type.IsClass)
                {
                    PythonObject pythonObject = new PythonObject(pythonAssembly);
                    pythonObject.Order = pythonObjectCounter;
                    pythonObject.Generate = true;
                    pythonObject.Name = type.Name;
                    pythonObject.PythonName = type.Name;
                    pythonObject.BaseClassName = type.BaseType.Name;
                    pythonObject.BaseClassPythonName = pythonObject.BaseClassName == "Object" ? "object" : pythonObject.BaseClassName;
                    pythonObject.ObjectPropertyCollection = new List<PythonObjectProperty>();
                    pythonObject.GenerateCreateMethod = false;
                    pythonObject.CreateMethodName = string.Format("create{0}", pythonObject.PythonName);
                    pythonObject.CodeForClass = "";
                    pythonObject.AdditionalCode = "";

                    pythonObject.CodeForCollectionClass = "";

                    int counter = 0;
                    foreach (PropertyInfo propertyInfo in type.GetProperties())
                    {
                        PythonObjectProperty pythonProperty = new PythonObjectProperty(pythonObject)
                        {
                            Generate = (propertyInfo.Name != "_className"),
                            Name = propertyInfo.Name,
                            FullName = string.Format("{0}.{1}", pythonObject.Name, propertyInfo.Name),
                            PythonName = propertyInfo.Name,
                            TypeName = propertyInfo.PropertyType.Name,
                            PythonTypeName = propertyInfo.PropertyType.Name,
                            UseInCreateMethod = false,
                            CreateMethodParameterOrder = counter++,
                            Order = counter - 1,
                            DefaultValue = "",
                            CodeForGetter = "",
                            GenerateGetter = true,
                            CodeForSetter = "",
                            GenerateSetter = true,
                            WasNotDeclaredInThisClass = propertyInfo.DeclaringType.Name != type.Name,
                        };

                        if (propertyInfo.PropertyType.Name == "IEnumerable`1")
                        {
                            pythonProperty.IsCollection = true;
                            pythonProperty.IsCollectionOf = propertyInfo.PropertyType.GenericTypeArguments[0].Name;

                            if (configurationEntries.ContainsKey(pythonProperty.IsCollectionOf))
                            {
                                var entry = (Dictionary<string, object>)configurationEntries[pythonProperty.IsCollectionOf];

                                pythonProperty.IsCollectionOfPrimitiveType = (bool)entry["IsPythonPrimitiveType"];
                                pythonProperty.IsCollectionOfPythonType = (string)entry["PythonTypeName"];
                            }
                        }

                        if (configurationEntries.ContainsKey(propertyInfo.PropertyType.Name))
                        {
                            var entry = (Dictionary<string, object>)configurationEntries[propertyInfo.PropertyType.Name];

                            pythonProperty.PythonTypeName = (string)entry["PythonTypeName"];
                            pythonProperty.IsPythonPrimitiveType = (bool)entry["IsPythonPrimitiveType"]; ;
                            pythonProperty.IsDateTime = (bool)entry["IsDateTime"];
                        }
                        else
                        {
                            pythonProperty.IsPythonPrimitiveType = false;
                        }

                        ((List<PythonObjectProperty>)pythonObject.ObjectPropertyCollection).Add(pythonProperty);
                    }

                    ((List<PythonObject>)pythonAssembly.Objects).Add(pythonObject);

                    pythonObjectCounter++;
                }
            }

            foreach (PythonObject pythonObject in pythonAssembly.Objects)
            {
                foreach (PythonObjectProperty pythonObjectProperty in pythonObject.ObjectPropertyCollection.Where(item => item.IsCollection))
                {
                    if (pythonObjectProperty.IsCollectionOfPrimitiveType)
                    {
                        pythonObjectProperty.PythonTypeName = $"ListOf_{pythonObjectProperty.IsCollectionOfPythonType}";
                    }
                    else
                    {
                        pythonObjectProperty.PythonTypeName = string.Format("{0}Collection", pythonAssembly.Objects.Where(item => item.Name == pythonObjectProperty.IsCollectionOf).FirstOrDefault().PythonName);
                    }
                }

                foreach (PythonObjectProperty pythonObjectProperty in pythonObject.ObjectPropertyCollection.Where(item => !item.IsCollection))
                {
                    pythonObjectProperty.IsEnumeration = pythonAssembly.Enums.Where(item => item.Name == pythonObjectProperty.TypeName).FirstOrDefault() != null;
                }
            }

            bool doItAgain = false;
            bool nothingWasUpdated = false;

            do
            {
                doItAgain = false;

                do
                {
                    nothingWasUpdated = true;
                    foreach (PythonObject pythonObject1 in pythonAssembly.Objects)
                    {
                        foreach (PythonObject pythonObject2 in pythonAssembly.Objects.Where(item => item.Name != pythonObject1.Name))
                        {
                            foreach (PythonObjectProperty pythonProperty in pythonObject2.ObjectPropertyCollection.Where(item => item.TypeName == pythonObject1.Name))
                            {
                                if (pythonObject2.Order < pythonObject1.Order)
                                {
                                    MoveObjectBefore(pythonAssembly, pythonObject1, pythonObject2.Order);
                                    nothingWasUpdated = false;
                                    doItAgain = true;
                                    break;
                                }
                            }
                        }
                    }
                } while (!nothingWasUpdated);

                do
                {
                    nothingWasUpdated = true;
                    foreach (PythonObject pythonObject1 in pythonAssembly.Objects)
                    {
                        foreach (PythonObject pythonObject2 in pythonAssembly.Objects.Where(item => item.Name != pythonObject1.Name))
                        {
                            foreach (PythonObjectProperty pythonProperty in pythonObject2.ObjectPropertyCollection.Where(item => item.IsCollection && item.IsCollectionOf == pythonObject1.Name))
                            {
                                if (pythonObject2.Order < pythonObject1.Order)
                                {
                                    MoveObjectBefore(pythonAssembly, pythonObject1, pythonObject2.Order);
                                    nothingWasUpdated = false;
                                    doItAgain = true;
                                    break;
                                }
                            }
                        }
                    }
                } while (!nothingWasUpdated);

                do
                {
                    nothingWasUpdated = true;
                    foreach (PythonObject pythonObject1 in pythonAssembly.Objects)
                    {
                        foreach (PythonObject pythonObject2 in pythonAssembly.Objects.Where(item => item.BaseClassName == pythonObject1.Name && item.Name != pythonObject1.Name))
                        {
                            if (pythonObject2.Order < pythonObject1.Order)
                            {
                                MoveObjectBefore(pythonAssembly, pythonObject1, pythonObject2.Order);
                                nothingWasUpdated = false;
                                doItAgain = true;
                                break;
                            }
                        }
                    }
                } while (!nothingWasUpdated);
            } while (doItAgain);

            foreach (var p in pythonAssembly.Objects)
            {
                foreach (var t in p.ObjectPropertyCollection.Where(item => item.IsCollection))
                {
                    var po = pythonAssembly.Objects.Where(item => item.Name == t.IsCollectionOf).FirstOrDefault();
                    if (po != null)
                    {
                        po.NeedsPythonCollectionClass = true;
                    }
                }
            }

            if (File.Exists(originalObjectModelFile))
            {
                PythonAssembly originalPythonAssembly = new PythonAssembly();

                if (File.Exists(originalObjectModelFile))
                {
                    originalPythonAssembly = JsonConvert.DeserializeObject<PythonAssembly>(File.ReadAllText(originalObjectModelFile));
                }

                pythonAssembly.AdditionalCodeAtEnd = originalPythonAssembly.AdditionalCodeAtEnd;
                pythonAssembly.AdditionalCodeAtStart = originalPythonAssembly.AdditionalCodeAtStart;
                pythonAssembly.AdditionalImportStatements = originalPythonAssembly.AdditionalImportStatements;

                foreach (PythonEnum pythonEnum in pythonAssembly.Enums)
                {
                    PythonEnum oldPythonEnum = originalPythonAssembly.Enums.Where(item => item.Name == pythonEnum.Name).FirstOrDefault();

                    if (oldPythonEnum != null)
                    {
                        pythonEnum.Generate = oldPythonEnum.Generate;
                        pythonEnum.PythonName = oldPythonEnum.PythonName;

                        foreach (PythonEnumValue pythonEnumValue in pythonEnum.EnumValueCollection)
                        {
                            PythonEnumValue oldPythonEnumValue = oldPythonEnum.EnumValueCollection.Where(item => item.Name == pythonEnumValue.Name).FirstOrDefault();
                            if (oldPythonEnumValue != null)
                            {
                                pythonEnumValue.Generate = oldPythonEnumValue.Generate;
                                pythonEnumValue.PythonName = oldPythonEnumValue.PythonName;
                                pythonEnumValue.PythonValue = oldPythonEnumValue.PythonValue;
                            }
                        }
                    }
                }

                foreach (PythonObject pythonObject in pythonAssembly.Objects)
                {
                    PythonObject oldPythonObject = originalPythonAssembly.Objects.Where(item => item.Name == pythonObject.Name).FirstOrDefault();

                    if (oldPythonObject != null)
                    {
                        pythonObject.Generate = oldPythonObject.Generate;
                        pythonObject.PythonName = oldPythonObject.PythonName;
                        pythonObject.BaseClassPythonName = oldPythonObject.BaseClassPythonName;
                        pythonObject.GenerateCreateMethod = oldPythonObject.GenerateCreateMethod;
                        pythonObject.CreateMethodName = oldPythonObject.CreateMethodName;
                        pythonObject.CodeForClass = oldPythonObject.CodeForClass;
                        pythonObject.AdditionalCode = oldPythonObject.AdditionalCode;
                        pythonObject.CodeForCollectionClass = oldPythonObject.CodeForCollectionClass;

                        foreach (PythonObjectProperty pythonObjectProperty in pythonObject.ObjectPropertyCollection)
                        {
                            PythonObjectProperty oldPythonObjectProperty = oldPythonObject.ObjectPropertyCollection.Where(item => item.Name == pythonObjectProperty.Name).FirstOrDefault();
                            if (oldPythonObjectProperty != null)
                            {
                                pythonObjectProperty.Generate = oldPythonObjectProperty.Generate;
                                pythonObjectProperty.PythonName = oldPythonObjectProperty.PythonName;
                                pythonObjectProperty.PythonTypeName = oldPythonObjectProperty.PythonTypeName;
                                pythonObjectProperty.Order = oldPythonObjectProperty.Order;
                                pythonObjectProperty.UseInCreateMethod = oldPythonObjectProperty.UseInCreateMethod;
                                pythonObjectProperty.CreateMethodParameterOrder = oldPythonObjectProperty.CreateMethodParameterOrder;
                                pythonObjectProperty.DefaultValue = oldPythonObjectProperty.DefaultValue;
                                pythonObjectProperty.CodeForGetter = oldPythonObjectProperty.CodeForGetter;
                                pythonObjectProperty.GenerateGetter = oldPythonObjectProperty.GenerateGetter;
                                pythonObjectProperty.CodeForSetter = oldPythonObjectProperty.CodeForSetter;
                                pythonObjectProperty.GenerateSetter = oldPythonObjectProperty.GenerateSetter;
                            }
                        }
                    }
                }
            }

            pythonAssembly.Objects = pythonAssembly.Objects.OrderBy(item => item.Order);
            foreach (PythonObject pythonObject in pythonAssembly.Objects)
            {
                pythonObject.ObjectPropertyCollection = pythonObject.ObjectPropertyCollection.OrderBy(item => item.Order);
            }

            string json = Newtonsoft.Json.JsonConvert.SerializeObject(pythonAssembly, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(newObjectModelFile, json);

            return pythonAssembly;
        }
    }
}
