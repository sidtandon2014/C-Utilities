﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace ReflectionLibrary
{
    public class PythonObjectProperty
    {
        public PythonObjectProperty(PythonObject pythonObject)
        {
            this.PythonObject = pythonObject;
        }

        [JsonIgnore]
        public PythonObject PythonObject { get; set; }
        public string Name { get; set; }
        public string FullName { get; set; }
        public string PythonName { get; set; }
        public string TypeName { get; set; }
        public string PythonTypeName { get; set; }
        public bool IsCollection { get; set; }
        public string IsCollectionOf { get; set; }
        public bool IsCollectionOfPrimitiveType { get; set; }
        public string IsCollectionOfPythonType { get; set; }
        public bool IsPythonPrimitiveType { get; set; }
        public bool IsEnumeration { get; set; }
        public bool IsDateTime { get; set; }
        public bool Generate { get; set; }
        public int Order { get; set; }
        public bool UseInCreateMethod { get; set; }
        public int CreateMethodParameterOrder { get; set; }
        public string DefaultValue { get; set; }
        public bool WasNotDeclaredInThisClass { get; set; }
        public string CodeForGetter { get; set; }
        public bool GenerateGetter { get; set; }
        public string CodeForSetter { get; set; }
        public bool GenerateSetter { get; set; }
    }
}
