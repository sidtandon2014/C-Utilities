﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReflectionLibrary
{
    public class PythonEnumValue
    {
        public PythonEnumValue(PythonEnum pythonEnum)
        {
            this.PythonEnum = pythonEnum;
        }

        [JsonIgnore]
        public PythonEnum PythonEnum { get; set; }

        public string Name { get; set; }
        public string FullName { get; set; }
        public string PythonName { get; set; }
        public string Value { get; set; }
        public string PythonValue { get; set; }
        public bool Generate { get; set; }

    }
}
