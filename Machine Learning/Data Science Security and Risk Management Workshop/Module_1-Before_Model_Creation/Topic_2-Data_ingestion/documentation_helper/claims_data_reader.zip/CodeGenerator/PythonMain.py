﻿#-------------- GENERATED FILE. DO NOT EDIT !!! ---------------------
#
# @owner Pascal Belaud
# Generated on: 2020-06-19 18:46:14 EST
#
#--------------------------------------------------------------------
import Library
import datetime
import json
import sys

# Here is how to create a new instance of type: Auto
def demo_Auto_Usage() -> Library.Auto:

    theAuto: Library.Auto = Library.Auto()

    # Here is how to manage the Auto Python primitive type based properties
    theAuto.Make = "YourMake"
    theAuto.Model = "YourModel"
    theAuto.Year = 5

    return theAuto

def test_Auto() -> str:

    theAuto1: Library.Auto = demo_Auto_Usage()
    json1: str = json.dumps(theAuto1, indent=4, cls=Library.CustomEncoder)
    theAuto2: Library.Auto = json.loads(json1, cls=Library.CustomDecoder)
    json2: str = json.dumps(theAuto2, indent=4, cls=Library.CustomEncoder)
    assert json1 == json2

    return json1

# Here is how to create a new instance of type: Capital
def demo_Capital_Usage() -> Library.Capital:

    theCapital: Library.Capital = Library.Capital()

    # Here is how to manage the Capital Python primitive type based properties
    theCapital.Gains = 5.0
    theCapital.Loss = 5.0

    return theCapital

def test_Capital() -> str:

    theCapital1: Library.Capital = demo_Capital_Usage()
    json1: str = json.dumps(theCapital1, indent=4, cls=Library.CustomEncoder)
    theCapital2: Library.Capital = json.loads(json1, cls=Library.CustomDecoder)
    json2: str = json.dumps(theCapital2, indent=4, cls=Library.CustomEncoder)
    assert json1 == json2

    return json1

# Here is how to create a new instance of type: Incident
def demo_Incident_Usage() -> Library.Incident:

    theIncident: Library.Incident = Library.Incident()

    # Here is how to manage the Incident Python primitive type based properties
    theIncident.City = "YourCity"
    theIncident.Date = Library.getUtcDate(2020, 6, 19, 18, 46, 14, 812000) # or Library.now() or Library.parseDate("2020-03-22T6:13:54.1254+05:30")
    theIncident.HourOfTheDay = 5
    theIncident.Location = "YourLocation"
    theIncident.State = "YourState"

    # Here is how to manage the Incident enumeration properties
    theIncident.Severity = Library.IncidentSeverityEnum.TrivialDamage # or getIncidentSeverityEnum("TrivialDamage")
    theIncident.Type = Library.IncidentEnum.MultiVehicleCollision # or getIncidentEnum("MultiVehicleCollision")

    return theIncident

def test_Incident() -> str:

    theIncident1: Library.Incident = demo_Incident_Usage()
    json1: str = json.dumps(theIncident1, indent=4, cls=Library.CustomEncoder)
    theIncident2: Library.Incident = json.loads(json1, cls=Library.CustomDecoder)
    json2: str = json.dumps(theIncident2, indent=4, cls=Library.CustomEncoder)
    assert json1 == json2

    return json1

# Here is how to create a new instance of type: Insured
def demo_Insured_Usage() -> Library.Insured:

    theInsured: Library.Insured = Library.Insured()

    # Here is how to manage the Insured Python primitive type based properties
    theInsured.Hobbies = "YourHobbies"
    theInsured.Occupation = "YourOccupation"
    theInsured.Zip = "YourZip"

    # Here is how to manage the Insured enumeration properties
    theInsured.EducationLevel = Library.EducationLevelEnum.Associate # or getEducationLevelEnum("Associate")
    theInsured.Relationship = Library.RelationshipEnum.Husband # or getRelationshipEnum("Husband")
    theInsured.Sex = Library.SexEnum.Male # or getSexEnum("Male")

    return theInsured

def test_Insured() -> str:

    theInsured1: Library.Insured = demo_Insured_Usage()
    json1: str = json.dumps(theInsured1, indent=4, cls=Library.CustomEncoder)
    theInsured2: Library.Insured = json.loads(json1, cls=Library.CustomDecoder)
    json2: str = json.dumps(theInsured2, indent=4, cls=Library.CustomEncoder)
    assert json1 == json2

    return json1

# Here is how to create a new instance of type: Policy
def demo_Policy_Usage() -> Library.Policy:

    thePolicy: Library.Policy = Library.Policy()

    # Here is how to manage the Policy Python primitive type based properties
    thePolicy.AnnualPremium = 5.0
    thePolicy.BindDate = Library.getUtcDate(2020, 6, 19, 18, 46, 14, 813000) # or Library.now() or Library.parseDate("2020-03-22T6:13:54.1254+05:30")
    thePolicy.Deductable = 5.0
    thePolicy.Number = "YourNumber"
    thePolicy.State = "YourState"

    # Here is how to manage the Policy enumeration properties
    thePolicy.Csl = Library.CslEnum.Csl_100_300 # or getCslEnum("Csl_100_300")

    return thePolicy

def test_Policy() -> str:

    thePolicy1: Library.Policy = demo_Policy_Usage()
    json1: str = json.dumps(thePolicy1, indent=4, cls=Library.CustomEncoder)
    thePolicy2: Library.Policy = json.loads(json1, cls=Library.CustomDecoder)
    json2: str = json.dumps(thePolicy2, indent=4, cls=Library.CustomEncoder)
    assert json1 == json2

    return json1

# Here is how to create a new instance of type: Property
def demo_Property_Usage() -> Library.Property:

    theProperty: Library.Property = Library.Property()

    # Here is how to manage the Property Python primitive type based properties
    theProperty.Claim = 5.0

    # Here is how to manage the Property enumeration properties
    theProperty.Damage = Library.ExtendedBoolean.Yes # or getExtendedBoolean("Yes")

    return theProperty

def test_Property() -> str:

    theProperty1: Library.Property = demo_Property_Usage()
    json1: str = json.dumps(theProperty1, indent=4, cls=Library.CustomEncoder)
    theProperty2: Library.Property = json.loads(json1, cls=Library.CustomDecoder)
    json2: str = json.dumps(theProperty2, indent=4, cls=Library.CustomEncoder)
    assert json1 == json2

    return json1

# Here is how to create a new instance of type: Claim
def demo_Claim_Usage() -> Library.Claim:

    theClaim: Library.Claim = Library.Claim()

    # Here is how to manage the Claim Python primitive type based properties
    theClaim.Age = 5
    theClaim.BodilyInjuries = 5
    theClaim.InjuryClaim = 5.0
    theClaim.MonthsAsCustomer = 5
    theClaim.NumberOfVehiclesInvolved = 5
    theClaim.TotalClaimAmount = 5.0
    theClaim.UmbrellaLimit = 5.0
    theClaim.VehicleClaim = 5.0
    theClaim.Witnesses = 5

    # Here is how to manage the Claim strongly typed properties
    theClaim.Auto = demo_Auto_Usage()

    theClaim.Capital = demo_Capital_Usage()

    theClaim.Incident = demo_Incident_Usage()

    theClaim.Insured = demo_Insured_Usage()

    theClaim.Policy = demo_Policy_Usage()

    theClaim.Property = demo_Property_Usage()

    # Here is how to manage the Claim enumeration properties
    theClaim.AuthoritiesContacted = Library.AuthorityEnum.NoAuthority # or getAuthorityEnum("NoAuthority")
    theClaim.CollisionType = Library.CollisionEnum.Front # or getCollisionEnum("Front")
    theClaim.FraudReported = Library.ExtendedBoolean.Yes # or getExtendedBoolean("Yes")
    theClaim.PoliceReportAvailable = Library.ExtendedBoolean.Yes # or getExtendedBoolean("Yes")

    return theClaim

def test_Claim() -> str:

    theClaim1: Library.Claim = demo_Claim_Usage()
    json1: str = json.dumps(theClaim1, indent=4, cls=Library.CustomEncoder)
    theClaim2: Library.Claim = json.loads(json1, cls=Library.CustomDecoder)
    json2: str = json.dumps(theClaim2, indent=4, cls=Library.CustomEncoder)
    assert json1 == json2

    return json1

# Here is how to create a new instance of type: Root
def demo_Root_Usage() -> Library.Root:

    theRoot: Library.Root = Library.Root()

    # Here is how to manage the Root collection properties
    theRoot.ClaimCollection = Library.ClaimCollection()
    for _ in range(0, 10, 1):
        theRoot.ClaimCollection.append(demo_Claim_Usage())

    return theRoot

def test_Root() -> str:

    theRoot1: Library.Root = demo_Root_Usage()
    json1: str = json.dumps(theRoot1, indent=4, cls=Library.CustomEncoder)
    theRoot2: Library.Root = json.loads(json1, cls=Library.CustomDecoder)
    json2: str = json.dumps(theRoot2, indent=4, cls=Library.CustomEncoder)
    assert json1 == json2

    return json1


def TestLibrary():
    try:
        print (Library.Version())

        print(test_Auto())
        print(test_Capital())
        print(test_Incident())
        print(test_Insured())
        print(test_Policy())
        print(test_Property())
        print(test_Claim())
        print(test_Root())

    except:
        print("Unexpected error: ", sys.exc_info()[0])
        raise
