﻿#-------------- GENERATED FILE. DO NOT EDIT !!! ---------------------
#
# @owner Pascal Belaud
# Generated on: 2020-06-19 18:46:14 EST
#
#--------------------------------------------------------------------
from enum import Enum
from typing import List, Dict
from datetime import datetime, timezone
import pytz
import sys
import json
import hashlib
import pandas

NULL_VALUE = None

def Version() -> str:
    return "2020-06-19 18:46:14 EST"

def checkType(var, varName, expectedType):
    if not (var is expectedType or var is type(None)):
        raise TypeError("Type passed for [{}] was [{}]. Type [{}] was expected instead.".format(varName[4:], var, expectedType))

def dateFormatString():
    return "%Y-%m-%dT%H:%M:%S.%f%z"

def dateFormatString2():
    return "%Y-%m-%dT%H:%M:%S%z"

def formatDate(theDatetime: datetime) -> str:
    if theDatetime is NULL_VALUE: return None
    return theDatetime.astimezone(pytz.utc).strftime(dateFormatString())

def parseDate(stringDate: str) -> datetime:
    if stringDate is NULL_VALUE: return None
    if stringDate == "0001-01-01T00:00:00": return None
    try:
        return datetime.strptime(stringDate, dateFormatString())
    except ValueError:
        return datetime.strptime(stringDate, dateFormatString2())
    except:
        raise

def now() -> datetime:
    return datetime.now(timezone.utc)

def getUtcDate(year, month, day, hour, minute, second, microsecond) -> datetime:
    return datetime(year, month, day, hour, minute, second, microsecond, tzinfo=timezone.utc)

def getTimeZoneDate(year, month, day, hour, minute, second, microsecond, timezone) -> datetime:
    return datetime(year, month, day, hour, minute, second, microsecond, timezone)

class ListOf_int(List[int]):

    __slots__ = []

    def append(self, item: int):
        if not type(item) is int:
            raise TypeError("Type passed to [ListOf_int.append()] was [{}]. Type [int] was expected instead.".format(type(item)))

        super().append(item)

class ListOf_bool(List[bool]):

    __slots__ = []

    def append(self, item: bool):
        if not type(item) is bool:
            raise TypeError("Type passed to [ListOf_bool.append()] was [{}]. Type [bool] was expected instead.".format(type(item)))

        super().append(item)

class ListOf_float(List[float]):

    __slots__ = []

    def append(self, item: float):
        if not type(item) is float:
            raise TypeError("Type passed to [ListOf_float.append()] was [{}]. Type [float] was expected instead.".format(type(item)))

        super().append(item)

class ListOf_datetime(List[datetime]):

    __slots__ = []

    def append(self, item: datetime):
        if not type(item) is datetime:
            raise TypeError("Type passed to [ListOf_datetime.append()] was [{}]. Type [datetime] was expected instead.".format(type(item)))

        super().append(item)

class ListOf_str(List[str]):

    __slots__ = []

    def append(self, item: str):
        if not type(item) is str:
            raise TypeError("Type passed to [ListOf_str.append()] was [{}]. Type [str] was expected instead.".format(type(item)))

        super().append(item)

class AuthorityEnum (Enum):
    NoAuthority = 1
    Ambulance = 2
    Fire = 3
    Police = 4
    Other = 5

    @classmethod
    def _getKeys(self):
        print("Enumeration: {}".format("AuthorityEnum"))
        print("  {} [{}]".format("NoAuthority", 1))
        print("  {} [{}]".format("Ambulance", 2))
        print("  {} [{}]".format("Fire", 3))
        print("  {} [{}]".format("Police", 4))
        print("  {} [{}]".format("Other", 5))

def getAuthorityEnum(name: str) -> AuthorityEnum:
    if name is NULL_VALUE: return None
    return AuthorityEnum[name]

class CollisionEnum (Enum):
    Front = 1
    Rear = 2
    Side = 3
    Unknown = 4

    @classmethod
    def _getKeys(self):
        print("Enumeration: {}".format("CollisionEnum"))
        print("  {} [{}]".format("Front", 1))
        print("  {} [{}]".format("Rear", 2))
        print("  {} [{}]".format("Side", 3))
        print("  {} [{}]".format("Unknown", 4))

def getCollisionEnum(name: str) -> CollisionEnum:
    if name is NULL_VALUE: return None
    return CollisionEnum[name]

class CslEnum (Enum):
    Csl_100_300 = 1
    Csl_250_500 = 2
    Csl_500_1000 = 3

    @classmethod
    def _getKeys(self):
        print("Enumeration: {}".format("CslEnum"))
        print("  {} [{}]".format("Csl_100_300", 1))
        print("  {} [{}]".format("Csl_250_500", 2))
        print("  {} [{}]".format("Csl_500_1000", 3))

def getCslEnum(name: str) -> CslEnum:
    if name is NULL_VALUE: return None
    return CslEnum[name]

class EducationLevelEnum (Enum):
    Associate = 1
    College = 2
    HighSchool = 3
    JD = 4
    MD = 5
    Masters = 6
    PhD = 7

    @classmethod
    def _getKeys(self):
        print("Enumeration: {}".format("EducationLevelEnum"))
        print("  {} [{}]".format("Associate", 1))
        print("  {} [{}]".format("College", 2))
        print("  {} [{}]".format("HighSchool", 3))
        print("  {} [{}]".format("JD", 4))
        print("  {} [{}]".format("MD", 5))
        print("  {} [{}]".format("Masters", 6))
        print("  {} [{}]".format("PhD", 7))

def getEducationLevelEnum(name: str) -> EducationLevelEnum:
    if name is NULL_VALUE: return None
    return EducationLevelEnum[name]

class IncidentSeverityEnum (Enum):
    TrivialDamage = 1
    MinorDamage = 2
    MajorDamage = 3
    TotalLoss = 4

    @classmethod
    def _getKeys(self):
        print("Enumeration: {}".format("IncidentSeverityEnum"))
        print("  {} [{}]".format("TrivialDamage", 1))
        print("  {} [{}]".format("MinorDamage", 2))
        print("  {} [{}]".format("MajorDamage", 3))
        print("  {} [{}]".format("TotalLoss", 4))

def getIncidentSeverityEnum(name: str) -> IncidentSeverityEnum:
    if name is NULL_VALUE: return None
    return IncidentSeverityEnum[name]

class IncidentEnum (Enum):
    MultiVehicleCollision = 1
    ParkedCar = 2
    SingleVehicleCollision = 3
    VehicleTheft = 4

    @classmethod
    def _getKeys(self):
        print("Enumeration: {}".format("IncidentEnum"))
        print("  {} [{}]".format("MultiVehicleCollision", 1))
        print("  {} [{}]".format("ParkedCar", 2))
        print("  {} [{}]".format("SingleVehicleCollision", 3))
        print("  {} [{}]".format("VehicleTheft", 4))

def getIncidentEnum(name: str) -> IncidentEnum:
    if name is NULL_VALUE: return None
    return IncidentEnum[name]

class ExtendedBoolean (Enum):
    Yes = 1
    No = 2
    Unknown = 3

    @classmethod
    def _getKeys(self):
        print("Enumeration: {}".format("ExtendedBoolean"))
        print("  {} [{}]".format("Yes", 1))
        print("  {} [{}]".format("No", 2))
        print("  {} [{}]".format("Unknown", 3))

def getExtendedBoolean(name: str) -> ExtendedBoolean:
    if name is NULL_VALUE: return None
    return ExtendedBoolean[name]

class RelationshipEnum (Enum):
    Husband = 1
    Wife = 2
    Unmarried = 3
    OwnChild = 4
    OtherRelative = 5
    NotInFamily = 6

    @classmethod
    def _getKeys(self):
        print("Enumeration: {}".format("RelationshipEnum"))
        print("  {} [{}]".format("Husband", 1))
        print("  {} [{}]".format("Wife", 2))
        print("  {} [{}]".format("Unmarried", 3))
        print("  {} [{}]".format("OwnChild", 4))
        print("  {} [{}]".format("OtherRelative", 5))
        print("  {} [{}]".format("NotInFamily", 6))

def getRelationshipEnum(name: str) -> RelationshipEnum:
    if name is NULL_VALUE: return None
    return RelationshipEnum[name]

class SexEnum (Enum):
    Male = 1
    Female = 2

    @classmethod
    def _getKeys(self):
        print("Enumeration: {}".format("SexEnum"))
        print("  {} [{}]".format("Male", 1))
        print("  {} [{}]".format("Female", 2))

def getSexEnum(name: str) -> SexEnum:
    if name is NULL_VALUE: return None
    return SexEnum[name]

class Auto(object):

    __slots__ = ["_Make", "_Model", "_Year"]

    def __init__(self):
        self._Make: str
        self._Model: str
        self._Year: int

    @staticmethod
    def createAuto(theMake: str, theModel: str, theYear: int):
        item: Auto = Auto()
        item.Make = theMake
        item.Model = theModel
        item.Year = theYear
        return item

    def _show(self):
        print(json.dumps(self, cls=CustomEncoder, indent=4))

    def _getKeys(self):
        print("{}:".format("Auto"))
        print("  {} [{}]".format("Make", "str"))
        print("  {} [{}]".format("Model", "str"))
        print("  {} [{}]".format("Year", "int"))

#Property Make
    def get_Make(self) -> str:
        return self._Make

    def set_Make(self, value: str):
        checkType(type(value), sys._getframe().f_code.co_name, str)
        self._Make = value

    Make = property(get_Make, set_Make)
#EndProperty Make

#Property Model
    def get_Model(self) -> str:
        return self._Model

    def set_Model(self, value: str):
        checkType(type(value), sys._getframe().f_code.co_name, str)
        self._Model = value

    Model = property(get_Model, set_Model)
#EndProperty Model

#Property Year
    def get_Year(self) -> int:
        return self._Year

    def set_Year(self, value: int):
        checkType(type(value), sys._getframe().f_code.co_name, int)
        self._Year = value

    Year = property(get_Year, set_Year)
#EndProperty Year

class Capital(object):

    __slots__ = ["_Gains", "_Loss"]

    def __init__(self):
        self._Gains: float
        self._Loss: float

    @staticmethod
    def createCapital(theGains: float, theLoss: float):
        item: Capital = Capital()
        item.Gains = theGains
        item.Loss = theLoss
        return item

    def _show(self):
        print(json.dumps(self, cls=CustomEncoder, indent=4))

    def _getKeys(self):
        print("{}:".format("Capital"))
        print("  {} [{}]".format("Gains", "float"))
        print("  {} [{}]".format("Loss", "float"))

#Property Gains
    def get_Gains(self) -> float:
        return self._Gains

    def set_Gains(self, value: float):
        checkType(type(value), sys._getframe().f_code.co_name, float)
        self._Gains = value

    Gains = property(get_Gains, set_Gains)
#EndProperty Gains

#Property Loss
    def get_Loss(self) -> float:
        return self._Loss

    def set_Loss(self, value: float):
        checkType(type(value), sys._getframe().f_code.co_name, float)
        self._Loss = value

    Loss = property(get_Loss, set_Loss)
#EndProperty Loss

class Incident(object):

    __slots__ = ["_City", "_Date", "_HourOfTheDay", "_Location", "_Severity", "_State", "_Type"]

    def __init__(self):
        self._City: str
        self._Date: datetime
        self._HourOfTheDay: int
        self._Location: str
        self._Severity: IncidentSeverityEnum
        self._State: str
        self._Type: IncidentEnum

    @staticmethod
    def createIncident(theCity: str, theDate: datetime, theHourOfTheDay: int, theLocation: str, theSeverity: IncidentSeverityEnum, theState: str, theType: IncidentEnum):
        item: Incident = Incident()
        item.City = theCity
        item.Date = theDate
        item.HourOfTheDay = theHourOfTheDay
        item.Location = theLocation
        item.Severity = theSeverity
        item.State = theState
        item.Type = theType
        return item

    def _show(self):
        print(json.dumps(self, cls=CustomEncoder, indent=4))

    def _getKeys(self):
        print("{}:".format("Incident"))
        print("  {} [{}]".format("City", "str"))
        print("  {} [{}]".format("Date", "datetime"))
        print("  {} [{}]".format("HourOfTheDay", "int"))
        print("  {} [{}]".format("Location", "str"))
        print("  {} [{}]".format("Severity", "IncidentSeverityEnum"))
        print("  {} [{}]".format("State", "str"))
        print("  {} [{}]".format("Type", "IncidentEnum"))

#Property City
    def get_City(self) -> str:
        return self._City

    def set_City(self, value: str):
        checkType(type(value), sys._getframe().f_code.co_name, str)
        self._City = value

    City = property(get_City, set_City)
#EndProperty City

#Property Date
    def get_Date(self) -> datetime:
        return self._Date

    def set_Date(self, value: datetime):
        checkType(type(value), sys._getframe().f_code.co_name, datetime)
        self._Date = value

    Date = property(get_Date, set_Date)
#EndProperty Date

#Property HourOfTheDay
    def get_HourOfTheDay(self) -> int:
        return self._HourOfTheDay

    def set_HourOfTheDay(self, value: int):
        checkType(type(value), sys._getframe().f_code.co_name, int)
        self._HourOfTheDay = value

    HourOfTheDay = property(get_HourOfTheDay, set_HourOfTheDay)
#EndProperty HourOfTheDay

#Property Location
    def get_Location(self) -> str:
        return self._Location

    def set_Location(self, value: str):
        checkType(type(value), sys._getframe().f_code.co_name, str)
        self._Location = value

    Location = property(get_Location, set_Location)
#EndProperty Location

#Property Severity
    def get_Severity(self) -> IncidentSeverityEnum:
        return self._Severity

    def set_Severity(self, value: IncidentSeverityEnum):
        checkType(type(value), sys._getframe().f_code.co_name, IncidentSeverityEnum)
        self._Severity = value

    Severity = property(get_Severity, set_Severity)
#EndProperty Severity

#Property State
    def get_State(self) -> str:
        return self._State

    def set_State(self, value: str):
        checkType(type(value), sys._getframe().f_code.co_name, str)
        self._State = value

    State = property(get_State, set_State)
#EndProperty State

#Property Type
    def get_Type(self) -> IncidentEnum:
        return self._Type

    def set_Type(self, value: IncidentEnum):
        checkType(type(value), sys._getframe().f_code.co_name, IncidentEnum)
        self._Type = value

    Type = property(get_Type, set_Type)
#EndProperty Type

class Insured(object):

    __slots__ = ["_EducationLevel", "_Hobbies", "_Occupation", "_Relationship", "_Sex", "_Zip"]

    def __init__(self):
        self._EducationLevel: EducationLevelEnum
        self._Hobbies: str
        self._Occupation: str
        self._Relationship: RelationshipEnum
        self._Sex: SexEnum
        self._Zip: str

    @staticmethod
    def createInsured(theHobbies: str, theOccupation: str, theRelationship: RelationshipEnum, theSex: SexEnum, theZip: str):
        item: Insured = Insured()
        item.Hobbies = theHobbies
        item.Occupation = theOccupation
        item.Relationship = theRelationship
        item.Sex = theSex
        item.Zip = theZip
        return item

    def _show(self):
        print(json.dumps(self, cls=CustomEncoder, indent=4))

    def _getKeys(self):
        print("{}:".format("Insured"))
        print("  {} [{}]".format("EducationLevel", "EducationLevelEnum"))
        print("  {} [{}]".format("Hobbies", "str"))
        print("  {} [{}]".format("Occupation", "str"))
        print("  {} [{}]".format("Relationship", "RelationshipEnum"))
        print("  {} [{}]".format("Sex", "SexEnum"))
        print("  {} [{}]".format("Zip", "str"))

#Property EducationLevel
    def get_EducationLevel(self) -> EducationLevelEnum:
        return self._EducationLevel

    def set_EducationLevel(self, value: EducationLevelEnum):
        checkType(type(value), sys._getframe().f_code.co_name, EducationLevelEnum)
        self._EducationLevel = value

    EducationLevel = property(get_EducationLevel, set_EducationLevel)
#EndProperty EducationLevel

#Property Hobbies
    def get_Hobbies(self) -> str:
        return self._Hobbies

    def set_Hobbies(self, value: str):
        checkType(type(value), sys._getframe().f_code.co_name, str)
        self._Hobbies = value

    Hobbies = property(get_Hobbies, set_Hobbies)
#EndProperty Hobbies

#Property Occupation
    def get_Occupation(self) -> str:
        return self._Occupation

    def set_Occupation(self, value: str):
        checkType(type(value), sys._getframe().f_code.co_name, str)
        self._Occupation = value

    Occupation = property(get_Occupation, set_Occupation)
#EndProperty Occupation

#Property Relationship
    def get_Relationship(self) -> RelationshipEnum:
        return self._Relationship

    def set_Relationship(self, value: RelationshipEnum):
        checkType(type(value), sys._getframe().f_code.co_name, RelationshipEnum)
        self._Relationship = value

    Relationship = property(get_Relationship, set_Relationship)
#EndProperty Relationship

#Property Sex
    def get_Sex(self) -> SexEnum:
        return self._Sex

    def set_Sex(self, value: SexEnum):
        checkType(type(value), sys._getframe().f_code.co_name, SexEnum)
        self._Sex = value

    Sex = property(get_Sex, set_Sex)
#EndProperty Sex

#Property Zip
    def get_Zip(self) -> str:
        return self._Zip

    def set_Zip(self, value: str):
        checkType(type(value), sys._getframe().f_code.co_name, str)
        self._Zip = value

    Zip = property(get_Zip, set_Zip)
#EndProperty Zip

class Policy(object):

    __slots__ = ["_AnnualPremium", "_BindDate", "_Csl", "_Deductable", "_Number", "_State"]

    def __init__(self):
        self._AnnualPremium: float
        self._BindDate: datetime
        self._Csl: CslEnum
        self._Deductable: float
        self._Number: str
        self._State: str

    @staticmethod
    def createPolicy(theAnnualPremium: float, theBindDate: datetime, theCsl: CslEnum, theDeductable: float, theNumber: str, theState: str):
        item: Policy = Policy()
        item.AnnualPremium = theAnnualPremium
        item.BindDate = theBindDate
        item.Csl = theCsl
        item.Deductable = theDeductable
        item.Number = theNumber
        item.State = theState
        return item

    def _show(self):
        print(json.dumps(self, cls=CustomEncoder, indent=4))

    def _getKeys(self):
        print("{}:".format("Policy"))
        print("  {} [{}]".format("AnnualPremium", "float"))
        print("  {} [{}]".format("BindDate", "datetime"))
        print("  {} [{}]".format("Csl", "CslEnum"))
        print("  {} [{}]".format("Deductable", "float"))
        print("  {} [{}]".format("Number", "str"))
        print("  {} [{}]".format("State", "str"))

#Property AnnualPremium
    def get_AnnualPremium(self) -> float:
        return self._AnnualPremium

    def set_AnnualPremium(self, value: float):
        checkType(type(value), sys._getframe().f_code.co_name, float)
        self._AnnualPremium = value

    AnnualPremium = property(get_AnnualPremium, set_AnnualPremium)
#EndProperty AnnualPremium

#Property BindDate
    def get_BindDate(self) -> datetime:
        return self._BindDate

    def set_BindDate(self, value: datetime):
        checkType(type(value), sys._getframe().f_code.co_name, datetime)
        self._BindDate = value

    BindDate = property(get_BindDate, set_BindDate)
#EndProperty BindDate

#Property Csl
    def get_Csl(self) -> CslEnum:
        return self._Csl

    def set_Csl(self, value: CslEnum):
        checkType(type(value), sys._getframe().f_code.co_name, CslEnum)
        self._Csl = value

    Csl = property(get_Csl, set_Csl)
#EndProperty Csl

#Property Deductable
    def get_Deductable(self) -> float:
        return self._Deductable

    def set_Deductable(self, value: float):
        checkType(type(value), sys._getframe().f_code.co_name, float)
        self._Deductable = value

    Deductable = property(get_Deductable, set_Deductable)
#EndProperty Deductable

#Property Number
    def get_Number(self) -> str:
        return self._Number

    def set_Number(self, value: str):
        checkType(type(value), sys._getframe().f_code.co_name, str)
        self._Number = value

    Number = property(get_Number, set_Number)
#EndProperty Number

#Property State
    def get_State(self) -> str:
        return self._State

    def set_State(self, value: str):
        checkType(type(value), sys._getframe().f_code.co_name, str)
        self._State = value

    State = property(get_State, set_State)
#EndProperty State

class Property(object):

    __slots__ = ["_Claim", "_Damage"]

    def __init__(self):
        self._Claim: float
        self._Damage: ExtendedBoolean

    @staticmethod
    def createProperty(theClaim: float, theDamage: ExtendedBoolean):
        item: Property = Property()
        item.Claim = theClaim
        item.Damage = theDamage
        return item

    def _show(self):
        print(json.dumps(self, cls=CustomEncoder, indent=4))

    def _getKeys(self):
        print("{}:".format("Property"))
        print("  {} [{}]".format("Claim", "float"))
        print("  {} [{}]".format("Damage", "ExtendedBoolean"))

#Property Claim
    def get_Claim(self) -> float:
        return self._Claim

    def set_Claim(self, value: float):
        checkType(type(value), sys._getframe().f_code.co_name, float)
        self._Claim = value

    Claim = property(get_Claim, set_Claim)
#EndProperty Claim

#Property Damage
    def get_Damage(self) -> ExtendedBoolean:
        return self._Damage

    def set_Damage(self, value: ExtendedBoolean):
        checkType(type(value), sys._getframe().f_code.co_name, ExtendedBoolean)
        self._Damage = value

    Damage = property(get_Damage, set_Damage)
#EndProperty Damage

class Claim(object):

    __slots__ = ["_Auto", "_Capital", "_Incident", "_Insured", "_Policy", "_Property", "_Age", "_AuthoritiesContacted", "_BodilyInjuries", "_CollisionType", "_FraudReported", "_InjuryClaim", "_MonthsAsCustomer", "_NumberOfVehiclesInvolved", "_PoliceReportAvailable", "_TotalClaimAmount", "_UmbrellaLimit", "_VehicleClaim", "_Witnesses"]

    def __init__(self):
        self._Auto: Auto
        self._Capital: Capital
        self._Incident: Incident
        self._Insured: Insured
        self._Policy: Policy
        self._Property: Property
        self._Age: int
        self._AuthoritiesContacted: AuthorityEnum
        self._BodilyInjuries: int
        self._CollisionType: CollisionEnum
        self._FraudReported: ExtendedBoolean
        self._InjuryClaim: float
        self._MonthsAsCustomer: int
        self._NumberOfVehiclesInvolved: int
        self._PoliceReportAvailable: ExtendedBoolean
        self._TotalClaimAmount: float
        self._UmbrellaLimit: float
        self._VehicleClaim: float
        self._Witnesses: int

    @staticmethod
    def createClaim(theAuto: Auto, theCapital: Capital, theIncident: Incident, theInsured: Insured, thePolicy: Policy, theProperty: Property, theAge: int, theAuthoritiesContacted: AuthorityEnum, theBodilyInjuries: int, theCollisionType: CollisionEnum, theFraudReported: ExtendedBoolean, theInjuryClaim: float, theMonthsAsCustomer: int, theNumberOfVehiclesInvolved: int, thePoliceReportAvailable: ExtendedBoolean, theTotalClaimAmount: float, theUmbrellaLimit: float, theVehicleClaim: float, theWitnesses: int):
        item: Claim = Claim()
        item.Auto = theAuto
        item.Capital = theCapital
        item.Incident = theIncident
        item.Insured = theInsured
        item.Policy = thePolicy
        item.Property = theProperty
        item.Age = theAge
        item.AuthoritiesContacted = theAuthoritiesContacted
        item.BodilyInjuries = theBodilyInjuries
        item.CollisionType = theCollisionType
        item.FraudReported = theFraudReported
        item.InjuryClaim = theInjuryClaim
        item.MonthsAsCustomer = theMonthsAsCustomer
        item.NumberOfVehiclesInvolved = theNumberOfVehiclesInvolved
        item.PoliceReportAvailable = thePoliceReportAvailable
        item.TotalClaimAmount = theTotalClaimAmount
        item.UmbrellaLimit = theUmbrellaLimit
        item.VehicleClaim = theVehicleClaim
        item.Witnesses = theWitnesses
        return item

    def _show(self):
        print(json.dumps(self, cls=CustomEncoder, indent=4))

    def _getKeys(self):
        print("{}:".format("Claim"))
        print("  {} [{}]".format("Age", "int"))
        print("  {} [{}]".format("AuthoritiesContacted", "AuthorityEnum"))
        print("  {} [{}]".format("Auto", "Auto"))
        print("  {} [{}]".format("BodilyInjuries", "int"))
        print("  {} [{}]".format("Capital", "Capital"))
        print("  {} [{}]".format("CollisionType", "CollisionEnum"))
        print("  {} [{}]".format("FraudReported", "ExtendedBoolean"))
        print("  {} [{}]".format("Incident", "Incident"))
        print("  {} [{}]".format("InjuryClaim", "float"))
        print("  {} [{}]".format("Insured", "Insured"))
        print("  {} [{}]".format("MonthsAsCustomer", "int"))
        print("  {} [{}]".format("NumberOfVehiclesInvolved", "int"))
        print("  {} [{}]".format("PoliceReportAvailable", "ExtendedBoolean"))
        print("  {} [{}]".format("Policy", "Policy"))
        print("  {} [{}]".format("Property", "Property"))
        print("  {} [{}]".format("TotalClaimAmount", "float"))
        print("  {} [{}]".format("UmbrellaLimit", "float"))
        print("  {} [{}]".format("VehicleClaim", "float"))
        print("  {} [{}]".format("Witnesses", "int"))

#Property Auto
    def get_Auto(self) -> Auto:
        return self._Auto

    def set_Auto(self, value: Auto):
        checkType(type(value), sys._getframe().f_code.co_name, Auto)
        self._Auto = value

    Auto = property(get_Auto, set_Auto)
#EndProperty Auto

#Property Capital
    def get_Capital(self) -> Capital:
        return self._Capital

    def set_Capital(self, value: Capital):
        checkType(type(value), sys._getframe().f_code.co_name, Capital)
        self._Capital = value

    Capital = property(get_Capital, set_Capital)
#EndProperty Capital

#Property Incident
    def get_Incident(self) -> Incident:
        return self._Incident

    def set_Incident(self, value: Incident):
        checkType(type(value), sys._getframe().f_code.co_name, Incident)
        self._Incident = value

    Incident = property(get_Incident, set_Incident)
#EndProperty Incident

#Property Insured
    def get_Insured(self) -> Insured:
        return self._Insured

    def set_Insured(self, value: Insured):
        checkType(type(value), sys._getframe().f_code.co_name, Insured)
        self._Insured = value

    Insured = property(get_Insured, set_Insured)
#EndProperty Insured

#Property Policy
    def get_Policy(self) -> Policy:
        return self._Policy

    def set_Policy(self, value: Policy):
        checkType(type(value), sys._getframe().f_code.co_name, Policy)
        self._Policy = value

    Policy = property(get_Policy, set_Policy)
#EndProperty Policy

#Property Property
    def get_Property(self) -> Property:
        return self._Property

    def set_Property(self, value: Property):
        checkType(type(value), sys._getframe().f_code.co_name, Property)
        self._Property = value

    Property = property(get_Property, set_Property)
#EndProperty Property

#Property Age
    def get_Age(self) -> int:
        return self._Age

    def set_Age(self, value: int):
        checkType(type(value), sys._getframe().f_code.co_name, int)
        self._Age = value

    Age = property(get_Age, set_Age)
#EndProperty Age

#Property AuthoritiesContacted
    def get_AuthoritiesContacted(self) -> AuthorityEnum:
        return self._AuthoritiesContacted

    def set_AuthoritiesContacted(self, value: AuthorityEnum):
        checkType(type(value), sys._getframe().f_code.co_name, AuthorityEnum)
        self._AuthoritiesContacted = value

    AuthoritiesContacted = property(get_AuthoritiesContacted, set_AuthoritiesContacted)
#EndProperty AuthoritiesContacted

#Property BodilyInjuries
    def get_BodilyInjuries(self) -> int:
        return self._BodilyInjuries

    def set_BodilyInjuries(self, value: int):
        checkType(type(value), sys._getframe().f_code.co_name, int)
        self._BodilyInjuries = value

    BodilyInjuries = property(get_BodilyInjuries, set_BodilyInjuries)
#EndProperty BodilyInjuries

#Property CollisionType
    def get_CollisionType(self) -> CollisionEnum:
        return self._CollisionType

    def set_CollisionType(self, value: CollisionEnum):
        checkType(type(value), sys._getframe().f_code.co_name, CollisionEnum)
        self._CollisionType = value

    CollisionType = property(get_CollisionType, set_CollisionType)
#EndProperty CollisionType

#Property FraudReported
    def get_FraudReported(self) -> ExtendedBoolean:
        return self._FraudReported

    def set_FraudReported(self, value: ExtendedBoolean):
        checkType(type(value), sys._getframe().f_code.co_name, ExtendedBoolean)
        self._FraudReported = value

    FraudReported = property(get_FraudReported, set_FraudReported)
#EndProperty FraudReported

#Property InjuryClaim
    def get_InjuryClaim(self) -> float:
        return self._InjuryClaim

    def set_InjuryClaim(self, value: float):
        checkType(type(value), sys._getframe().f_code.co_name, float)
        self._InjuryClaim = value

    InjuryClaim = property(get_InjuryClaim, set_InjuryClaim)
#EndProperty InjuryClaim

#Property MonthsAsCustomer
    def get_MonthsAsCustomer(self) -> int:
        return self._MonthsAsCustomer

    def set_MonthsAsCustomer(self, value: int):
        checkType(type(value), sys._getframe().f_code.co_name, int)
        self._MonthsAsCustomer = value

    MonthsAsCustomer = property(get_MonthsAsCustomer, set_MonthsAsCustomer)
#EndProperty MonthsAsCustomer

#Property NumberOfVehiclesInvolved
    def get_NumberOfVehiclesInvolved(self) -> int:
        return self._NumberOfVehiclesInvolved

    def set_NumberOfVehiclesInvolved(self, value: int):
        checkType(type(value), sys._getframe().f_code.co_name, int)
        self._NumberOfVehiclesInvolved = value

    NumberOfVehiclesInvolved = property(get_NumberOfVehiclesInvolved, set_NumberOfVehiclesInvolved)
#EndProperty NumberOfVehiclesInvolved

#Property PoliceReportAvailable
    def get_PoliceReportAvailable(self) -> ExtendedBoolean:
        return self._PoliceReportAvailable

    def set_PoliceReportAvailable(self, value: ExtendedBoolean):
        checkType(type(value), sys._getframe().f_code.co_name, ExtendedBoolean)
        self._PoliceReportAvailable = value

    PoliceReportAvailable = property(get_PoliceReportAvailable, set_PoliceReportAvailable)
#EndProperty PoliceReportAvailable

#Property TotalClaimAmount
    def get_TotalClaimAmount(self) -> float:
        return self._TotalClaimAmount

    def set_TotalClaimAmount(self, value: float):
        checkType(type(value), sys._getframe().f_code.co_name, float)
        self._TotalClaimAmount = value

    TotalClaimAmount = property(get_TotalClaimAmount, set_TotalClaimAmount)
#EndProperty TotalClaimAmount

#Property UmbrellaLimit
    def get_UmbrellaLimit(self) -> float:
        return self._UmbrellaLimit

    def set_UmbrellaLimit(self, value: float):
        checkType(type(value), sys._getframe().f_code.co_name, float)
        self._UmbrellaLimit = value

    UmbrellaLimit = property(get_UmbrellaLimit, set_UmbrellaLimit)
#EndProperty UmbrellaLimit

#Property VehicleClaim
    def get_VehicleClaim(self) -> float:
        return self._VehicleClaim

    def set_VehicleClaim(self, value: float):
        checkType(type(value), sys._getframe().f_code.co_name, float)
        self._VehicleClaim = value

    VehicleClaim = property(get_VehicleClaim, set_VehicleClaim)
#EndProperty VehicleClaim

#Property Witnesses
    def get_Witnesses(self) -> int:
        return self._Witnesses

    def set_Witnesses(self, value: int):
        checkType(type(value), sys._getframe().f_code.co_name, int)
        self._Witnesses = value

    Witnesses = property(get_Witnesses, set_Witnesses)
#EndProperty Witnesses

class ClaimCollection(List[Claim]):

    __slots__ = []

    def append(self, item: Claim):
        if not type(item) is Claim:
            raise TypeError("Type passed to [ClaimCollection.append()] was [{}]. Type [Claim] was expected instead.".format(type(item)))

        super().append(item)

    def generateDataFrame(self) -> pandas.DataFrame:

        variables = [
          'Auto.Make',
          'Auto.Model',
          'Auto.Year',
          'Capital.Gains',
          'Capital.Loss',
          'Incident.City',
          'Incident.Date',
          'Incident.HourOfTheDay',
          'Incident.Location',
          'Incident.Severity',
          'Incident.State',
          'Incident.Type',
          'Insured.EducationLevel',
          'Insured.Hobbies',
          'Insured.Occupation',
          'Insured.Relationship',
          'Insured.Sex',
          'Insured.Zip',
          'Policy.AnnualPremium',
          'Policy.BindDate',
          'Policy.Csl',
          'Policy.Deductable',
          'Policy.Number',
          'Policy.State',
          'Property.Claim',
          'Property.Damage',
          'Age',
          'AuthoritiesContacted',
          'BodilyInjuries',
          'CollisionType',
          'FraudReported',
          'InjuryClaim',
          'MonthsAsCustomer',
          'NumberOfVehiclesInvolved',
          'PoliceReportAvailable',
          'TotalClaimAmount',
          'UmbrellaLimit',
          'VehicleClaim',
          'Witnesses'
        ]
        df = pandas.DataFrame([[
          o.Auto.Make,
          o.Auto.Model,
          o.Auto.Year,
          o.Capital.Gains,
          o.Capital.Loss,
          o.Incident.City,
          o.Incident.Date,
          o.Incident.HourOfTheDay,
          o.Incident.Location,
          o.Incident.Severity.name,
          o.Incident.State,
          o.Incident.Type.name,
          o.Insured.EducationLevel.name,
          o.Insured.Hobbies,
          o.Insured.Occupation,
          o.Insured.Relationship.name,
          o.Insured.Sex.name,
          o.Insured.Zip,
          o.Policy.AnnualPremium,
          o.Policy.BindDate,
          o.Policy.Csl.name,
          o.Policy.Deductable,
          o.Policy.Number,
          o.Policy.State,
          o.Property.Claim,
          o.Property.Damage.name,
          o.Age,
          o.AuthoritiesContacted.name,
          o.BodilyInjuries,
          o.CollisionType.name,
          o.FraudReported.name,
          o.InjuryClaim,
          o.MonthsAsCustomer,
          o.NumberOfVehiclesInvolved,
          o.PoliceReportAvailable.name,
          o.TotalClaimAmount,
          o.UmbrellaLimit,
          o.VehicleClaim,
          o.Witnesses
        ] for o in self], columns = variables)

        return df

    @staticmethod
    def LoadFromDataFrame(dataFrame: pandas.DataFrame):

        theClaimCollection: ClaimCollection = ClaimCollection()

        for row in dataFrame.iterrows():
            currentRow = row[1]

            theClaim: Claim = Claim()

            theClaim.Auto = currentRow['Claim.Auto']
            theClaim.Capital = currentRow['Claim.Capital']
            theClaim.Incident = currentRow['Claim.Incident']
            theClaim.Insured = currentRow['Claim.Insured']
            theClaim.Policy = currentRow['Claim.Policy']
            theClaim.Property = currentRow['Claim.Property']
            theClaim.Age = currentRow['Claim.Age']
            theClaim.AuthoritiesContacted = getAuthorityEnum(currentRow['Claim.AuthoritiesContacted'])
            theClaim.BodilyInjuries = currentRow['Claim.BodilyInjuries']
            theClaim.CollisionType = getCollisionEnum(currentRow['Claim.CollisionType'])
            theClaim.FraudReported = getExtendedBoolean(currentRow['Claim.FraudReported'])
            theClaim.InjuryClaim = currentRow['Claim.InjuryClaim']
            theClaim.MonthsAsCustomer = currentRow['Claim.MonthsAsCustomer']
            theClaim.NumberOfVehiclesInvolved = currentRow['Claim.NumberOfVehiclesInvolved']
            theClaim.PoliceReportAvailable = getExtendedBoolean(currentRow['Claim.PoliceReportAvailable'])
            theClaim.TotalClaimAmount = currentRow['Claim.TotalClaimAmount']
            theClaim.UmbrellaLimit = currentRow['Claim.UmbrellaLimit']
            theClaim.VehicleClaim = currentRow['Claim.VehicleClaim']
            theClaim.Witnesses = currentRow['Claim.Witnesses']

            theClaimCollection.append(theClaim)

        return theClaimCollection

    def _show(self):
        print(json.dumps(self, cls=CustomEncoder, indent=4))

    def _getKeys(self):
        print("Collection of")
        Claim()._getKeys()

class Root(object):

    __slots__ = ["_ClaimCollection"]

    def __init__(self):
        self._ClaimCollection: ClaimCollection

    @staticmethod
    def createRoot(theClaimCollection: ClaimCollection):
        item: Root = Root()
        item.ClaimCollection = theClaimCollection
        return item

    def _show(self):
        print(json.dumps(self, cls=CustomEncoder, indent=4))

    def _getKeys(self):
        print("{}:".format("Root"))
        print("  {} [{}]".format("ClaimCollection", "ClaimCollection"))

#Property ClaimCollection
    def get_ClaimCollection(self) -> ClaimCollection:
        if not hasattr(self, "_ClaimCollection"):
            self._ClaimCollection = ClaimCollection()
        return self._ClaimCollection

    def set_ClaimCollection(self, value: ClaimCollection):
        checkType(type(value), sys._getframe().f_code.co_name, ClaimCollection)
        self._ClaimCollection = value

    ClaimCollection = property(get_ClaimCollection, set_ClaimCollection)
#EndProperty ClaimCollection


class CustomEncoder(json.JSONEncoder):
 
    def default(self, o): # pylint: disable=E0202

        return self.buildJson(o, None)

    def buildJson(self, o, context): # pylint: disable=E0202

        if isinstance(o, type([])):
            jsonContent = []
            for item in o:
                if type(item) is int or type(item) is float or type(item) is bool or type(item) is str or type(item) is datetime:
                    jsonContent.append(item)
                else:
                    jsonContent.append(self.buildJson(item, context))
            return jsonContent

        if type(o) is Auto:
            return {
                        '_className': 'Auto',
                        'Make': o.Make if hasattr(o, "_Make") else NULL_VALUE,
                        'Model': o.Model if hasattr(o, "_Model") else NULL_VALUE,
                        'Year': o.Year if hasattr(o, "_Year") else NULL_VALUE,
                    }

        if type(o) is Capital:
            return {
                        '_className': 'Capital',
                        'Gains': o.Gains if hasattr(o, "_Gains") else NULL_VALUE,
                        'Loss': o.Loss if hasattr(o, "_Loss") else NULL_VALUE,
                    }

        if type(o) is Incident:
            return {
                        '_className': 'Incident',
                        'City': o.City if hasattr(o, "_City") else NULL_VALUE,
                        'Date': formatDate(o.Date) if hasattr(o, "_Date") else NULL_VALUE,
                        'HourOfTheDay': o.HourOfTheDay if hasattr(o, "_HourOfTheDay") else NULL_VALUE,
                        'Location': o.Location if hasattr(o, "_Location") else NULL_VALUE,
                        'Severity': o.Severity.name if hasattr(o, "_Severity") and not o.Severity is None else NULL_VALUE,
                        'State': o.State if hasattr(o, "_State") else NULL_VALUE,
                        'Type': o.Type.name if hasattr(o, "_Type") and not o.Type is None else NULL_VALUE,
                    }

        if type(o) is Insured:
            return {
                        '_className': 'Insured',
                        'EducationLevel': o.EducationLevel.name if hasattr(o, "_EducationLevel") and not o.EducationLevel is None else NULL_VALUE,
                        'Hobbies': o.Hobbies if hasattr(o, "_Hobbies") else NULL_VALUE,
                        'Occupation': o.Occupation if hasattr(o, "_Occupation") else NULL_VALUE,
                        'Relationship': o.Relationship.name if hasattr(o, "_Relationship") and not o.Relationship is None else NULL_VALUE,
                        'Sex': o.Sex.name if hasattr(o, "_Sex") and not o.Sex is None else NULL_VALUE,
                        'Zip': o.Zip if hasattr(o, "_Zip") else NULL_VALUE,
                    }

        if type(o) is Policy:
            return {
                        '_className': 'Policy',
                        'AnnualPremium': o.AnnualPremium if hasattr(o, "_AnnualPremium") else NULL_VALUE,
                        'BindDate': formatDate(o.BindDate) if hasattr(o, "_BindDate") else NULL_VALUE,
                        'Csl': o.Csl.name if hasattr(o, "_Csl") and not o.Csl is None else NULL_VALUE,
                        'Deductable': o.Deductable if hasattr(o, "_Deductable") else NULL_VALUE,
                        'Number': o.Number if hasattr(o, "_Number") else NULL_VALUE,
                        'State': o.State if hasattr(o, "_State") else NULL_VALUE,
                    }

        if type(o) is Property:
            return {
                        '_className': 'Property',
                        'Claim': o.Claim if hasattr(o, "_Claim") else NULL_VALUE,
                        'Damage': o.Damage.name if hasattr(o, "_Damage") and not o.Damage is None else NULL_VALUE,
                    }

        if type(o) is Claim:
            return {
                        '_className': 'Claim',
                        'Auto': CustomEncoder.default(self, o.Auto) if hasattr(o, "_Auto") else NULL_VALUE,
                        'Capital': CustomEncoder.default(self, o.Capital) if hasattr(o, "_Capital") else NULL_VALUE,
                        'Incident': CustomEncoder.default(self, o.Incident) if hasattr(o, "_Incident") else NULL_VALUE,
                        'Insured': CustomEncoder.default(self, o.Insured) if hasattr(o, "_Insured") else NULL_VALUE,
                        'Policy': CustomEncoder.default(self, o.Policy) if hasattr(o, "_Policy") else NULL_VALUE,
                        'Property': CustomEncoder.default(self, o.Property) if hasattr(o, "_Property") else NULL_VALUE,
                        'Age': o.Age if hasattr(o, "_Age") else NULL_VALUE,
                        'AuthoritiesContacted': o.AuthoritiesContacted.name if hasattr(o, "_AuthoritiesContacted") and not o.AuthoritiesContacted is None else NULL_VALUE,
                        'BodilyInjuries': o.BodilyInjuries if hasattr(o, "_BodilyInjuries") else NULL_VALUE,
                        'CollisionType': o.CollisionType.name if hasattr(o, "_CollisionType") and not o.CollisionType is None else NULL_VALUE,
                        'FraudReported': o.FraudReported.name if hasattr(o, "_FraudReported") and not o.FraudReported is None else NULL_VALUE,
                        'InjuryClaim': o.InjuryClaim if hasattr(o, "_InjuryClaim") else NULL_VALUE,
                        'MonthsAsCustomer': o.MonthsAsCustomer if hasattr(o, "_MonthsAsCustomer") else NULL_VALUE,
                        'NumberOfVehiclesInvolved': o.NumberOfVehiclesInvolved if hasattr(o, "_NumberOfVehiclesInvolved") else NULL_VALUE,
                        'PoliceReportAvailable': o.PoliceReportAvailable.name if hasattr(o, "_PoliceReportAvailable") and not o.PoliceReportAvailable is None else NULL_VALUE,
                        'TotalClaimAmount': o.TotalClaimAmount if hasattr(o, "_TotalClaimAmount") else NULL_VALUE,
                        'UmbrellaLimit': o.UmbrellaLimit if hasattr(o, "_UmbrellaLimit") else NULL_VALUE,
                        'VehicleClaim': o.VehicleClaim if hasattr(o, "_VehicleClaim") else NULL_VALUE,
                        'Witnesses': o.Witnesses if hasattr(o, "_Witnesses") else NULL_VALUE,
                    }

        if type(o) is Root:
            return {
                        '_className': 'Root',
                        'ClaimCollection': self.buildJson(o.ClaimCollection, "ClaimCollection"),
                    }

        if (o is None):
            return None

        return json.JSONEncoder.default(self, o)

class CustomDecoder(json.JSONDecoder):

    def __init__(self):
        json.JSONDecoder.__init__(self, object_hook=self.dict_to_object)

    def dict_to_object(self, dictionary):

        return self.dict_to_objectExtended(dictionary, None)

    def dict_to_objectExtended(self, dictionary, collection):
        if not collection is None:
            obj = []
            for item in dictionary:
                obj.append(self.dict_to_objectExtended(item, None))
        else:
            if "_className" in dictionary.keys():


                if dictionary["_className"] == "Auto":
                    obj: Auto = Auto()
                    obj.Make = dictionary["Make"]
                    obj.Model = dictionary["Model"]
                    obj.Year = dictionary["Year"]

                    return obj


                if dictionary["_className"] == "Capital":
                    obj: Capital = Capital()
                    obj.Gains = dictionary["Gains"]
                    obj.Loss = dictionary["Loss"]

                    return obj


                if dictionary["_className"] == "Incident":
                    obj: Incident = Incident()
                    obj.City = dictionary["City"]
                    obj.Date = parseDate(dictionary["Date"])
                    obj.HourOfTheDay = dictionary["HourOfTheDay"]
                    obj.Location = dictionary["Location"]
                    obj.Severity = getIncidentSeverityEnum(dictionary["Severity"])
                    obj.State = dictionary["State"]
                    obj.Type = getIncidentEnum(dictionary["Type"])

                    return obj


                if dictionary["_className"] == "Insured":
                    obj: Insured = Insured()
                    obj.EducationLevel = getEducationLevelEnum(dictionary["EducationLevel"])
                    obj.Hobbies = dictionary["Hobbies"]
                    obj.Occupation = dictionary["Occupation"]
                    obj.Relationship = getRelationshipEnum(dictionary["Relationship"])
                    obj.Sex = getSexEnum(dictionary["Sex"])
                    obj.Zip = dictionary["Zip"]

                    return obj


                if dictionary["_className"] == "Policy":
                    obj: Policy = Policy()
                    obj.AnnualPremium = dictionary["AnnualPremium"]
                    obj.BindDate = parseDate(dictionary["BindDate"])
                    obj.Csl = getCslEnum(dictionary["Csl"])
                    obj.Deductable = dictionary["Deductable"]
                    obj.Number = dictionary["Number"]
                    obj.State = dictionary["State"]

                    return obj


                if dictionary["_className"] == "Property":
                    obj: Property = Property()
                    obj.Claim = dictionary["Claim"]
                    obj.Damage = getExtendedBoolean(dictionary["Damage"])

                    return obj


                if dictionary["_className"] == "Claim":
                    obj: Claim = Claim()
                    obj.Auto = dictionary["Auto"]
                    obj.Capital = dictionary["Capital"]
                    obj.Incident = dictionary["Incident"]
                    obj.Insured = dictionary["Insured"]
                    obj.Policy = dictionary["Policy"]
                    obj.Property = dictionary["Property"]
                    obj.Age = dictionary["Age"]
                    obj.AuthoritiesContacted = getAuthorityEnum(dictionary["AuthoritiesContacted"])
                    obj.BodilyInjuries = dictionary["BodilyInjuries"]
                    obj.CollisionType = getCollisionEnum(dictionary["CollisionType"])
                    obj.FraudReported = getExtendedBoolean(dictionary["FraudReported"])
                    obj.InjuryClaim = dictionary["InjuryClaim"]
                    obj.MonthsAsCustomer = dictionary["MonthsAsCustomer"]
                    obj.NumberOfVehiclesInvolved = dictionary["NumberOfVehiclesInvolved"]
                    obj.PoliceReportAvailable = getExtendedBoolean(dictionary["PoliceReportAvailable"])
                    obj.TotalClaimAmount = dictionary["TotalClaimAmount"]
                    obj.UmbrellaLimit = dictionary["UmbrellaLimit"]
                    obj.VehicleClaim = dictionary["VehicleClaim"]
                    obj.Witnesses = dictionary["Witnesses"]

                    return obj


                if dictionary["_className"] == "Root":
                    obj: Root = Root()

                    if not dictionary["ClaimCollection"] is NULL_VALUE:
                        for item in dictionary["ClaimCollection"]:
                            obj.ClaimCollection.append(item)

                    return obj

                return dictionary

