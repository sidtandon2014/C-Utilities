import datetime
import json
import sys
import pandas
import Library
import Helpers

def get_authorities_contacted(value: str) -> Library.AuthorityEnum:

    if value == "Ambulance":
        return Library.AuthorityEnum.Ambulance
    elif value == "Fire":
        return Library.AuthorityEnum.Fire
    elif value == "None":
        return Library.AuthorityEnum.NoAuthority
    elif value == "Other":
        return Library.AuthorityEnum.Other
    elif value == "Police":
        return Library.AuthorityEnum.Police

    raise Exception("Unkown value for field [authorities_contacted]: [{}]".format(value))

def get_collision_type(value: str) -> Library.CollisionEnum:

    if value == "Front Collision":
        return Library.CollisionEnum.Front
    elif value == "Rear Collision":
        return Library.CollisionEnum.Rear
    elif value == "Side Collision":
        return Library.CollisionEnum.Side
    elif value == "?":
        return Library.CollisionEnum.Unknown

    raise Exception("Unkown value for field [collision_type]: [{}]".format(value))

def get_fraud_reported(value: str) -> Library.ExtendedBoolean:

    if value == "Y":
        return Library.ExtendedBoolean.Yes
    elif value == "N":
        return Library.ExtendedBoolean.No

    raise Exception("Unkown value for field [fraud_reported]: [{}]".format(value))

def get_police_report_available(value: str) -> Library.ExtendedBoolean:

    if value == "YES":
        return Library.ExtendedBoolean.Yes
    elif value == "NO":
        return Library.ExtendedBoolean.No
    elif value == "?":
        return Library.ExtendedBoolean.Unknown

    raise Exception("Unkown value for field [police_report_available]: [{}]".format(value))

def get_incident_severity(value: str) -> Library.IncidentSeverityEnum:

    if value == "Major Damage":
        return Library.IncidentSeverityEnum.MajorDamage
    elif value == "Minor Damage":
        return Library.IncidentSeverityEnum.MinorDamage
    elif value == "Total Loss":
        return Library.IncidentSeverityEnum.TotalLoss
    elif value == "Trivial Damage":
        return Library.IncidentSeverityEnum.TrivialDamage

    raise Exception("Unkown value for field [incident_severity]: [{}]".format(value))

def get_incident_type(value: str) -> Library.IncidentEnum:

    if value == "Single Vehicle Collision":
        return Library.IncidentEnum.SingleVehicleCollision
    elif value == "Multi-vehicle Collision":
        return Library.IncidentEnum.MultiVehicleCollision
    elif value == "Parked Car":
        return Library.IncidentEnum.ParkedCar
    elif value == "Vehicle Theft":
        return Library.IncidentEnum.VehicleTheft

    raise Exception("Unkown value for field [incident_type]: [{}]".format(value))

def get_property_damage(value: str) -> Library.ExtendedBoolean:

    if value == "YES":
        return Library.ExtendedBoolean.Yes
    elif value == "NO":
        return Library.ExtendedBoolean.No
    elif value == "?":
        return Library.ExtendedBoolean.Unknown

    raise Exception("Unkown value for field [property_damage]: [{}]".format(value))

def get_insured_education_level(value: str) -> Library.EducationLevelEnum:

    if value == "Associate":
        return Library.EducationLevelEnum.Associate
    elif value == "College":
        return Library.EducationLevelEnum.College
    elif value == "High School":
        return Library.EducationLevelEnum.HighSchool
    elif value == "JD":
        return Library.EducationLevelEnum.JD
    elif value == "Masters":
        return Library.EducationLevelEnum.Masters
    elif value == "MD":
        return Library.EducationLevelEnum.MD
    elif value == "PhD":
        return Library.EducationLevelEnum.PhD

    raise Exception("Unkown value for field [insured_education_level]: [{}]".format(value))

def get_insured_sex(value: str) -> Library.SexEnum:

    if value == "MALE":
        return Library.SexEnum.Male
    elif value == "FEMALE":
        return Library.SexEnum.Female

    raise Exception("Unkown value for field [insured_sex]: [{}]".format(value))

def get_insured_relationship(value: str) -> Library.RelationshipEnum:

    if value == "husband":
        return Library.RelationshipEnum.Husband
    elif value == "wife":
        return Library.RelationshipEnum.Wife
    elif value == "unmarried":
        return Library.RelationshipEnum.Unmarried
    elif value == "own-child":
        return Library.RelationshipEnum.OwnChild
    elif value == "other-relative":
        return Library.RelationshipEnum.OtherRelative
    elif value == "not-in-family":
        return Library.RelationshipEnum.NotInFamily

    raise Exception("Unkown value for field [insured_relationship]: [{}]".format(value))

def get_policy_csl(value: str) -> Library.CslEnum:

    if value == "100/300":
        return Library.CslEnum.Csl_100_300
    elif value == "250/500":
        return Library.CslEnum.Csl_250_500
    elif value == "500/1000":
        return Library.CslEnum.Csl_500_1000

    raise Exception("Unkown value for field [policy_csl]: [{}]".format(value))

def LoadRow(row: pandas.core.series.Series) -> Library.Claim:

    claim: Library.Claim = Library.Claim()

    claim.InjuryClaim = float(row["injury_claim"])
    claim.TotalClaimAmount = float(row["total_claim_amount"])
    claim.UmbrellaLimit = float(row["umbrella_limit"])
    claim.VehicleClaim = float(row["vehicle_claim"])
    claim.Age = int(row["age"])
    claim.BodilyInjuries = int(row["bodily_injuries"])
    claim.MonthsAsCustomer = int(row["months_as_customer"])
    claim.NumberOfVehiclesInvolved = int(row["number_of_vehicles_involved"])
    claim.Witnesses = int(row["witnesses"])
    claim.AuthoritiesContacted = get_authorities_contacted(row["authorities_contacted"])
    claim.FraudReported = get_fraud_reported(row["fraud_reported"])
    claim.PoliceReportAvailable = get_police_report_available(row["police_report_available"])
    claim.CollisionType = get_collision_type(row["collision_type"])

    claim.Auto = Library.Auto()
    claim.Auto.Make = row["auto_make"]
    claim.Auto.Model = row["auto_model"]
    claim.Auto.Year = int(row["auto_year"])

    claim.Capital = Library.Capital()
    claim.Capital.Gains = float(row["capital-gains"])
    claim.Capital.Loss = float(row["capital-loss"])

    claim.Incident = Library.Incident()
    claim.Incident.City = row["incident_city"]

    incidentDate: str = row["incident_date"].replace("/", "-").split("-")
    claim.Incident.Date = Library.getUtcDate(int(incidentDate[2]), int(incidentDate[1]), int(incidentDate[0]), 0, 0, 0, 0)

    claim.Incident.HourOfTheDay = int(row["incident_hour_of_the_day"])
    claim.Incident.Location = row["incident_location"]
    claim.Incident.Severity = get_incident_severity(row["incident_severity"])
    claim.Incident.State = row["incident_state"]
    claim.Incident.Type = get_incident_type(row["incident_type"])

    claim.Insured = Library.Insured()
    claim.Insured.EducationLevel = get_insured_education_level(row["insured_education_level"])
    claim.Insured.Hobbies = row["insured_hobbies"]
    claim.Insured.Occupation = row["insured_occupation"]
    claim.Insured.Relationship = get_insured_relationship(row["insured_relationship"])
    claim.Insured.Sex = get_insured_sex(row["insured_sex"])
    claim.Insured.Zip = str(row["insured_zip"])

    claim.Policy = Library.Policy()
    claim.Policy.AnnualPremium = float(row["policy_annual_premium"])

    policyBindDate: str = row["policy_bind_date"].replace("/", "-").split("-")
    claim.Policy.BindDate = Library.getUtcDate(int(policyBindDate[2]), int(policyBindDate[1]), int(policyBindDate[0]), 0, 0, 0, 0)
    
    claim.Policy.Csl = get_policy_csl(row["policy_csl"])
    claim.Policy.Deductable = float(row["policy_deductable"])
    claim.Policy.Number = str(row["policy_number"])
    claim.Policy.State = row["policy_state"]

    claim.Property = Library.Property()
    claim.Property.Claim = float(row["property_claim"])
    claim.Property.Damage = get_property_damage(row["property_damage"])

    return claim

root: Library.Root = Library.Root()
df: pandas.DataFrame = pandas.read_csv("C:\\Users\\pascalbe\\Documents\\Jose\\insurance_claims_data.csv")

for index in range(0, 1000):
    root.ClaimCollection.append(LoadRow(df.iloc[index]))
#root._show()

newDf: pandas.DataFrame = root.ClaimCollection.generateDataFrame()
print(newDf)

print("Done")
