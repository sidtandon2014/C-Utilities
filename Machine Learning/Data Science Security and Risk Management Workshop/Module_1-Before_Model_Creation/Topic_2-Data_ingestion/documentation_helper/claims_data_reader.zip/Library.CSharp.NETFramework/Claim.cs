﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public class Claim
    {
        public Auto Auto { get; set; }
        public Capital Capital { get; set; }
        public Incident Incident { get; set; }
        public Insured Insured { get; set; }
        public Policy Policy { get; set; }
        public Property Property { get; set; }
        public int Age { get; set; }
        public AuthorityEnum AuthoritiesContacted { get; set; }
        public int BodilyInjuries { get; set; }
        public CollisionEnum CollisionType { get; set; }
        public ExtendedBoolean FraudReported { get; set; }
        public float InjuryClaim { get; set; }
        public int MonthsAsCustomer { get; set; }
        public int NumberOfVehiclesInvolved { get; set; }
        public ExtendedBoolean PoliceReportAvailable { get; set; }
        public float TotalClaimAmount { get; set; }
        public float UmbrellaLimit { get; set; }
        public float VehicleClaim { get; set; }
        public int Witnesses { get; set; }
    }
}
