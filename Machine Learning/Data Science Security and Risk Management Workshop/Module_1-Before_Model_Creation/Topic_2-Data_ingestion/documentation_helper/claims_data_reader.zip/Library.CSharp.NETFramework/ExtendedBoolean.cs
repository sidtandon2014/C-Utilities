﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public enum ExtendedBoolean
    {
        Yes = 1,
        No = 2,
        Unknown = 3,
    }
}
