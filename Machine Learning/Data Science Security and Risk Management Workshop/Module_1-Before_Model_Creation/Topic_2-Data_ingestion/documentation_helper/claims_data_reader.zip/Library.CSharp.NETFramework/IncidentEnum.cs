﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public enum IncidentEnum
    {
        MultiVehicleCollision = 1,
        ParkedCar = 2,
        SingleVehicleCollision = 3,
        VehicleTheft = 4,
    }
}
