﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public class Incident
    {
        public string City { get; set; }
        public DateTime Date { get; set; }
        public int HourOfTheDay { get; set; }
        public string Location { get; set; }
        public IncidentSeverityEnum Severity { get; set; }
        public string State { get; set; }
        public IncidentEnum Type { get; set; }
    }
}
