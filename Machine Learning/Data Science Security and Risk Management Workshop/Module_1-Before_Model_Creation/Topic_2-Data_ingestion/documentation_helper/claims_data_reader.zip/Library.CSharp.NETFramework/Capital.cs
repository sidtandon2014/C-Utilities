﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public class Capital
    {
        public float Gains { get; set; }
        public float Loss { get; set; }
    }
}
