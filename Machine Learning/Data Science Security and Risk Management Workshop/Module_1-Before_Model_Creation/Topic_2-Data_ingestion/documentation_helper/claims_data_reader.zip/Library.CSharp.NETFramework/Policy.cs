﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public class Policy
    {
        public float AnnualPremium { get; set; }
        public DateTime BindDate { get; set; }
        public CslEnum Csl { get; set; }
        public float Deductable { get; set; }
        public string Number { get; set; }
        public string State { get; set; }
    }
}
