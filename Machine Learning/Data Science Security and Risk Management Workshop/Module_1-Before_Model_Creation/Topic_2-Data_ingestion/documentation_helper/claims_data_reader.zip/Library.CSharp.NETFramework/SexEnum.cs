﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public enum SexEnum
    {
        Male = 1,
        Female = 2,
    }
}
