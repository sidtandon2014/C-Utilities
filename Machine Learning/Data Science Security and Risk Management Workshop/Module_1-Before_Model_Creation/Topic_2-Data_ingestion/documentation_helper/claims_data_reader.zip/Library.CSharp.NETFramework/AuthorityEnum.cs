﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public enum AuthorityEnum
    {
        NoAuthority = 1,
        Ambulance = 2,
        Fire = 3,
        Police = 4,
        Other = 5,
    }
}
