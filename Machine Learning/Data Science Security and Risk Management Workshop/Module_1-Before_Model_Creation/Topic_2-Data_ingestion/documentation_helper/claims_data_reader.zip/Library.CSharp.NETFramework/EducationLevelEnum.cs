﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public enum EducationLevelEnum
    {
        Associate = 1,
        College = 2,
        HighSchool = 3,
        JD = 4,
        MD = 5,
        Masters = 6,
        PhD = 7,
    }
}
