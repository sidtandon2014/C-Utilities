﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public class Root
    {
        public IEnumerable<Claim> ClaimCollection { get; set; }
    }
}
