﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public enum CslEnum
    {
        Csl_100_300 = 1,
        Csl_250_500 = 2,
        Csl_500_1000 = 3,
    }
}
