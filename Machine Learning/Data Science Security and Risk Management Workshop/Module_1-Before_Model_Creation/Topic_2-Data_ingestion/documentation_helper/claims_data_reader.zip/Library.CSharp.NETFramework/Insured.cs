﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public class Insured
    {
        public EducationLevelEnum EducationLevel { get; set; }
        public string Hobbies { get; set; }
        public string Occupation { get; set; }
        public RelationshipEnum Relationship { get; set; }
        public SexEnum Sex { get; set; }
        public string Zip { get; set; }
    }
}
