﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public enum IncidentSeverityEnum
    {
        TrivialDamage = 1,
        MinorDamage = 2,
        MajorDamage = 3,
        TotalLoss = 4,
    }
}
