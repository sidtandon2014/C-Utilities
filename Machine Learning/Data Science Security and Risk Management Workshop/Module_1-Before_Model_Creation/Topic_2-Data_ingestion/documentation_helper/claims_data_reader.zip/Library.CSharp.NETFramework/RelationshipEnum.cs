﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library.CSharp.NETFramework
{
    public enum RelationshipEnum
    {
        Husband = 1,
        Wife = 2,
        Unmarried = 3,
        OwnChild = 4,
        OtherRelative = 5,
        NotInFamily = 6,
    }
}
